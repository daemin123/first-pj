package com.example.app.type;

public enum ROLE {
	ROLE_USER,		//0
	ROLE_OFFER,		//1
	ROLE_SEEKER,	//2
	ROLE_ADMIN,		//3
}

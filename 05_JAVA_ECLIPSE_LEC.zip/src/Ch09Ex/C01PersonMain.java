package Ch09Ex;

class Profile1 {
	// 속성
	String name;
	String addr;
	String job;
	String major;
	// 생성자
	// 1) 디폴트 생성자 삽입
	Profile1() {
		
	}
	// 2) 모든 인자 받는 생성자 삽입 -> 각 멤버에 대입
	Profile1(String name, String addr, String job, String major) {
		this.name = name;
		this.addr = addr;
		this.job = job;
		this.major = major;
	}
	// 3) 모든 인자 받는 생성자 삽입(가변인자 사용할것) -> ,를 기준으로 잘라내어 각 속성에 저장
	// ex) "홍길동,대구,프로그래머,컴퓨터공학" -> [홍길동,대구,프로그래머.컴퓨터공학]
	Profile1(String arg) {
		String arr[] = arg.trim().split(",");
		this.name = arr[0];
		this.addr = arr[1];
		this.job = arr[2];
		this.major = arr[3];	
		}
	
	// 기능

	// 1) getter and setter 삽입
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	// 2) toString 재정의
	@Override
	public String toString() {
		return "Profile1 [name=" + name + ", addr=" + addr + ", job=" + job + ", major=" + major + "]";
	}
	
	// 3) boolean is Contain(String compare) 함수 완성하기
	boolean isContain(String findstr) {
		
		// findstr의 문자열이 각 멤버인 name,addr,job,major 중 하나라도 포함되어 있으면 true
		if(findstr.trim().contains(findstr)==true) {
			return true;
		}
		// 아니면 false 리턴
		else {
			return false;
		}
	}
	boolean isEquals(String str) {
//		 all로 받은 문자열을 , 단위로 잘라내어(split(",")) 각각 나눠진 문자열이
		String[] arr = str.trim().split(",");
		for (String val : arr) {
			if(val==)
		}
		// name, addr, job, major 와 일치하면 true
		// 아니면 false 리턴
		
	}

}
public class C01PersonMain {
	public static void main(String[] args) {
		Profile1 hong = new Profile1("홍길동,대구,프로그래머,컴퓨터공학");
		System.out.println(hong.toString());
		System.out.println("길동 포함 여부 : " + hong.isContain("길동"));
		System.out.println("컴퓨터 포함 여부 : " + hong.isContain("컴퓨터"));
		System.out.println("프로필 일치 여부 : " + hong.isEquals("홍길동,대구,프로그래머,컴퓨터공학"));
		System.out.println("프로필 일치 여부 : " + hong.isEquals("홍길동,울산,프로그래머,컴퓨터공학"));
	}
}

package Ch09;

// 접근 한정자
// 정보은닉 != 캡슐화
// 멤버/클래스의 접근 범위를 제한을 위한 예약어
// public		: 모든 클래스에서 접근 가능
// private		: 해당 클래스에서만 접근 가능
// protected	: 상속 관계를 가지는 경우에 접근 가능
// default(기본)	: 동일 패키지에 속한 클래스에서 접근 가능

// 일반인		// 공개여부	// 수정여부
// 이름		// 공개가능 	//	O
// 나이		// 공개가능	//	O
// 주소		// 비공개		//	O
// 성별		// 공개가능	//	X
// 학력		// 비공개		//	O
// 연봉		// 비공개		//	O
// 주민번호	// 비공개		//	X
// ...

// 연예인		// 공개여부	// 수정여부
// 이름		// 비공개 	//	O
// 나이		// 비공개		//	O
// 주소		// 비공개		//	O
// 성별		// 공개가능	//	X
// 학력		// 비공개		//	O
// 연봉		// 비공개		//	O
// 주민번호	// 비공개		//	X
//...

class C101Person {
	private String name;
	private int age;
	private String addr;
	
	public C101Person(String name, int age, String addr) {
		super();
		this.name = name;
		this.age = age;
		this.addr = addr;
	}
	// Getter : 조회의 성질
	String getName(){
		return this.name;
	}
	int getAge() {
		return this.age;
	}
	
	// Setter : 수정의 성질
	void setAge(int age) {
		this.age = age;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public void setName(String name) {
		this.name = name;
	}
	
//	@Override
//	public String toString() {
//		return "C101Person [name=" + name + ", age=" + age + ", addr=" + addr + "]";
//	}
	
	
}

public class C01정보은닉 {
	public static void main(String[] args) {
		C101Person ob1 = new C101Person("홍길동",55,"대구");
		System.out.println(ob1);
		System.out.println(ob1.getName());
		ob1.setAge(50);
		System.out.println(ob1.getAge());
	}
}





package Ch09;

// 캡슐화
// 작업 순서를 정확히 명시해줘야 한다
// 서로 연관있는 속성과 기능들을 하나의 캡슐로 만들어 데이터를 외부로부터 보호하는 것

// 데이터 보호 - 외부로부터 클래스에 정의된 속성과 기능들을 보호
// 데이터 은닉 - 내부의 동작을 감추고 외부에는 필요한 부분만 노출

// 여러가지 메서드를 묶어 하나의 함수로서 출력된다

// 캡슐화란 ?
// 특정 목적을 가지는 기능을 구현하는데 필요한 세부 기능들을 묶어서 처리하는 방법
// 특정 목적을 가지는 기능 구현에 있어서 각 과정에 일부나 전부가 외부로 노출되는 문제를 막기 위해
// 정보 은닉을 수반한다(필수는 아님)
// 캡슐화 과정은 각 공정 과정에 대한 정확한 이해가 수반되어야 한다

class Engine {
	private void 흡입() {System.out.println("외부로부터 공기를 빨아들인다");}
	private void 압축() {System.out.println("가둔 공기를 압축시킨다");}
	private void 폭발() {System.out.println("일정 수준만큼 압축되면 폭발");}
	private void 배기() {System.out.println("가스를 외부로 보낸다");}
	
	public void EngineStart() {
		
		흡입();
		압축();
		폭발();
		배기();
	}
}

class Car {
	Engine engine; // Engine 객체 생성을 위한 engine 참조 변수 선언
	Car(){
		engine = new Engine(); // engine 참조 변수를 통한 객체 생성
	}
	void run() {
		engine.EngineStart(); // Engine 객체의 EngineStart()메서드 실행 
	}
}
public class C02캡슐화 {
	public static void main(String[] args) {
		Car myCar = new Car();
		myCar.run();
	}
}

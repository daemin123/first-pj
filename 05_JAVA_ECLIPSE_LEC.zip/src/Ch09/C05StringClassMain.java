package Ch09;


public class C05StringClassMain {
	public static void main(String[] args) {
		String str1 = "java";
		String str2 = "java";
		String str3 = new String("java");
		String str4 = new String("java");
		
		// 선 저장 후 처리
		// 데이터 값 저장 -> 변수에 대입
		// 저장된 데이터값에 해당하는 메모리주소 -> 데이터 동일하면 같다
		// 1==2
		
		// String 객체 생성시에 참조 변수 str3,4는 서로 다른 객체
		
		System.out.printf("%x\n",System.identityHashCode(str1));
		System.out.printf("%x\n",System.identityHashCode(str2));
		System.out.printf("%x\n",System.identityHashCode(str3));
		System.out.printf("%x\n",System.identityHashCode(str4));
		
		System.out.println("str1==str2 ? " + (str1==str2));
		System.out.println("str3==str4 ? " + (str3==str4)); 
		System.out.println("str1==str3 ? " + (str1==str3)); 
		System.out.println("str1==str4 ? " + (str1==str4));
		System.out.println("------------------------");
		// .equals()==>데이터값 동일 여부 확인 메서드
		System.out.println("str1==str2 ? " + str1.equals(str2));
		System.out.println("str3==str4 ? " + str3.equals(str4)); 
		System.out.println("str1==str3 ? " + str1.equals(str3)); 
		System.out.println("str1==str4 ? " + str1.equals(str4));
		
		
	}
}

package Ch09;

import Ch08.C01Main;

// 라면
class 진라면Recipe{
	// 순서
	private void step1() {System.out.println("1 step");}
	private void step2() {System.out.println("2 step");}
	private void step3() {System.out.println("3 step");}
	private void step4() {System.out.println("4 step");}
	
	// 기능 묶기
	public void Cooking() {
		step1();
		step2();
		step3();
		step4();		
	}
}


// 요리사
class Cooker {
	public 진라면Recipe recipe01;
	Cooker() {
		recipe01 = new 진라면Recipe();
	}
	void Cook1() {
		recipe01.Cooking();
	}
}

public class C03캡슐화 {
	public static void main(String[] args) {
		Cooker hong = new Cooker();
		hong.recipe01.Cooking();
		hong.Cook1();
	}
}

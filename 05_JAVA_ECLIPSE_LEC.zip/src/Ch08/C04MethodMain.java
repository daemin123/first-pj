package Ch08;

import java.util.Scanner;

class MethodTest {
	// 속성
	public Scanner sc = new Scanner(System.in);
	
	// 기능
	public int sum1(int n1, int n2) {return n1+n2;} // 인자 o 반환 o
	public int sum2() {return sc.nextInt() + sc.nextInt();} // 인자 x 반환 o
	public void sum3(int n1, int n2) {System.out.println(n1+n2);} // 인자 o 반환 x
	public void sum4() {System.out.println(sc.nextInt() + sc.nextInt());} // 인자 x 반환 x
}
public class C04MethodMain {
	public static void main(String[] args) {
		MethodTest sumCalc = new MethodTest();
		System.out.println(sumCalc.sum1(10, 20));
		System.out.println(sumCalc.sum2());
		sumCalc.sum3(10, 20);
		sumCalc.sum4();
	}
}

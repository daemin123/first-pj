package Ch08;

class C01Person {
	// 속성
	String name;
	int age;
	float height;
	double weight;
	
	// 기능
	
}

package Ch08;
// *메서드 오버로딩*
// 함수의 명은 같으나 인자(개수,자료형)에 따라서 다양한 형태로 정의되는 메서드 형태.
// 함수의 반환 타입은 오버로딩에서 고려되지 않는다!
// 사용은 가능하나 오버로딩으로 정의되지 않는다.
// 함수를 찾아낼 때 함수명과 매개변수의 형태로 구별을 한다.

class C06Simple {
	int sum(int x, int y) {
		System.out.println("int sum(int x, int y)");
		return x + y;
	}
	int sum(int x, int y, int z) {
		System.out.println("int sum(int x, int y, int z)");
		return x + y + z;
	}
	int sum(double x, double y, double z) {
		System.out.println("int sum(double x, double y, double z)");
		return (int)(x + y + z);
	}
//	double sum(double x, double y, double z) {
//		System.out.println("int sum(double x, double y, double z)");
//		return (x + y + z);
//	}
//  인자의 자료형과 수가 같고 반환 자료형이 달라서 다른 함수로 보이지만 같은 로직을 갖고 있는 형태이므로 오버로딩으로 취급하지 않음
	
}

public class C06MethodOverloading {
	public static void main(String[] args) {
		C06Simple obj = new C06Simple();
		obj.sum(10,20);
		obj.sum(10,20,30);
		obj.sum(10,20.1,20.5);
	}
}

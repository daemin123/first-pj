package Ch12Ex;

abstract class A {
	abstract void f();
}
abstract class B {
	void f() {
		System.out.println("~");
	}
}

//abstract class B{
//	abstract void f();
//}
//class C extends B {
//	void f() {
//		
//	}
//}
//abstract class B {
//	abstract int f();
//}
//class C extends B {
//	int f() {
//		return 0;
//	}
//}
public class prac3 {
	public static void main(String[] args) {
		
	}
}

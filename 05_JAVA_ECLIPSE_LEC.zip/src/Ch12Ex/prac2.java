package Ch12Ex;

class A {
	private int a;
	protected A(int i) {a=i;}
}
class B extends A {
	private int b;
	public B() {super(1); b=0;}
}
public class prac2 {
	public static void main(String[] args) {
		
	}
}

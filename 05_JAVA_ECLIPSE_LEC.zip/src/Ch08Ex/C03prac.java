package Ch08Ex;

class TV {
	String a;
	int b;
	int c;
	TV(String a,int b, int c) {
		this.a =a;
		this.b= b;
		this.c= c;
	}
	void show() {
		System.out.println(this.a +"에서 만든" + this.b + "년형" + this.c + "인치TV");
	}
}
public class C03prac {
	public static void main(String[] args) {
		TV myTV = new TV("LG",2017,32);
		myTV.show();
	}
}

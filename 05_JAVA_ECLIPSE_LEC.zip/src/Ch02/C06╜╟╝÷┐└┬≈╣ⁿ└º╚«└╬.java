package Ch02;

public class C06실수오차범위확인 {
	
	
	public static void main(String[] args) {
		
		System.out.println("Float : "+(0.44444444444444444444F));
		System.out.println("Float : "+(0.77777777777777777777777777777777F));
		System.out.println("Float : "+(0.99999999999999999999999999999999F));
		System.out.println("Float : "+(0.22222222222222222222222222222222F));
		System.out.println("Double : "+(0.77777777777777777777777777777777));
		System.out.println("Double : "+(0.99999999999999999999999999999999));
		System.out.println("Double : "+(0.22222222222222222222222222222222));
				
	}

}

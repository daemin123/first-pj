package Ch03;

public class test {

	public static void main(String[] args) {
		double var1 = 3.5;
		double var2 = 2.7;
		int result = (int)var1 + (int)var2;
		System.out.println(result);

	}

}
